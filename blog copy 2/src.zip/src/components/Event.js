import React from "react";


var Event = function Event() {
  return (
    <>
      <h2>Event Name</h2>
      <p>date</p>
      <a href="Image URL">Img URL</a>
      <div>
        <h4>Things you saw</h4>
        <p>data.see</p>
      </div>
      <div>
        <h4>data.hear</h4>
        <p>data.hear</p>
      </div>
      <div>
        <h4>data.smell</h4>
        <p>data.smell</p>
      </div>
      <div>
        <h4>data.taste</h4>
        <p>data.taste</p>
      </div>
      <div>
        <button>Edit Memento</button>
        <button>Delete Memento</button>
      </div>
    </>
  );
};

export default Event;
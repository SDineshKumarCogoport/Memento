import React from 'react';

const BlogList = (props) => {
    const FavouriteComponent = props.favouriteComponent;
    return (
        <>
            
            {props.blogs.map((blog) => (
                <div className="images">
                    <h3>{blog.title}</h3>
                    <div onClick={() => props.handleFavouritesClick(blog)}>
                        <FavouriteComponent />
                    </div>
                </div>
            ))}
            
        </>
        
    );
};
export default BlogList;
import React from "react";
import{Link} from "react-router-dom"

export default function Form() {
  return (
    <>
      <div class="infoContainer ">
        <h1 className="BlogHeading">Add a Memento</h1>

        <div class="form">
          <form action="">
            <input type="text" placeholder="Event Name" />

            <input type="text" placeholder="Date" />
            <input type="text" placeholder="Image URL" />

            <input type="text" placeholder="Things you saw" />

            <input type="text" placeholder="Things you touched" />
            <input type="text" placeholder="Things you heared" />
            <input type="text" placeholder="Things you smelled" />
            <input type="text" placeholder="Things you tasted" />
            <input type="text" placeholder="Short Note" />

            <textarea
              name="message"
              id=""
              cols="20"
              rows="10"
              placeholder="Description"
            ></textarea>

           <Link to="/"> <button>Submit</button></Link>
          </form>
        </div>
      </div>
    </>
  );
}

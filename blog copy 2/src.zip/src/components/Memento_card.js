import React from "react";

var MementoCard = function MementoCard(){

    return(
        <>
        <div className="memento_card">
            <div className="memento_details">
            <h2 className="event_name">Event Name </h2>
            </div>
             {/* Event name is a variable */}
        </div>
        </>
    );


}

export default MementoCard;
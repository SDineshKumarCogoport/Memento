import React from "react";
import{Link} from "react-router-dom"





var Homepage = function Homepage(){

    return(
        <>
                <div className='center'>
                <div>
                <h1>Memento</h1>
                </div>

                
              <Link to="/CreateNew"> <button className="new-button" >Create New</button> </Link>
           
               
             
                
                

                <div className='blog-list' >
                
              
      <Link to="/Event">  <div className="memento_card">
            <div className="memento_details">
            <h2 className="event_name">Event Name </h2>
            </div>
             {/* Event name is a variable */}
        </div> </Link>
        

                </div>

                
                
            </div>
        </>

    );

}

export default Homepage;
import './App.css';
import React from "react";
import {
    BrowserRouter as Router,
    Routes,
    Route,
    BrowserRouter } from "react-router-dom";

import Event from './components/Event';

import Homepage from './components/home';
import Form from './components/CreateEvent';

function App() {
    return(
        <BrowserRouter>
            <Routes>
                <Route path='/' element={<Homepage/>}>
                </Route>  
                <Route path='/CreateNew' element={<Form/>}>
                </Route>
                <Route path='/Event' element={<Event/>}>
                </Route>

            </Routes>
        </BrowserRouter>
        
        
        
        
    );
}

export default App;

    






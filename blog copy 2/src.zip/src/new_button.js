import React from "react";

var NewButton = function(){

    return(
        <>
        <button className="new-button" >Create New</button>
        </>

    );

}

export default NewButton;